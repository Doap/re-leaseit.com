function et_init_plugin_fixes(){
	// et_plugin_data.folder
}