Thankyou for using Amora WordPress theme.
Amora WordPress theme is based on Underscores Framework http://underscore.me/, (C) 2012-2013 Automattic Inc.
The theme comes under GNU General Public license. For more details about the license, you can always refer to the license.txt file present in the theme.

##Copyright for Resources used in the theme.
	I.	Resource 	- Bootstrap Framework (used only to make responsive)
		License 	- MIT License
				  	  Copyright 2014, Twitter

	II.	Resource 	- skip-link-focus-fix.js, navigation.js, customizer.js & keyboard-image-navigation.js 
		License 	- GPL License
				  Copyright 2012-2013 Underscores.me Automattic Inc.

	III.Resource 	- Images
		License 	- CC0 1.0 Universal (CC0 1.0) [Public Domain Dedication]
		Copyright 	- No Copyright

		For more details -
 
		http://pixabay.com/en/photographer-tourist-snapshot-407068/
		http://pixabay.com/en/maple-maple-leaves-autumn-colorful-325974/
		http://pixabay.com/en/volkswagen-adventure-travel-vw-569315/

	IV.	Resource 	- Social Icons
		Soshions 	- This icon set was created by me. Also, its on 
		www.iconfinder.com under GPL. More details - www.divjot.co, https://www.iconfinder.com/

	V.	Resource 	- Fonts(Noto Sans)
		License 	- Open Source Web Font from Google

	VI.	Resource - Iconsets
				  Sociocons - These icons are released under gpl and free for commercial use at www.iconfinder.com
				  More details - https://www.iconfinder.com/iconsets/sociocons
				  
				  Soshions	- These are also a set of icons used in the theme. These are also released under GPL.
				  For more detail - Check out https://www.iconfinder.com/iconsets/soshions
				  
				  The last set of icons was designed by me and I distribute it under GPL license.

	VII.	Resource 	- BXSlider
		License		- WTFPL License	
				  For more info - http://bxslider.com/faqs AND http://sam.zoy.org/wtfpl/

Everything else used in this theme has been created by me, especially for Amora theme and is distributed under GPL license.

For any help, you can contact me at divjot_1992@gmail.com.