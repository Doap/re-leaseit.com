<?php
/**
 * full width header template(used in full width layout)
 */
 get_template_part( 'template/header' );
?>
  <div id="content" class="container">
    <div class="content-full-width clearfix">